declare function openUrl(url :String): void;
/**
 * 弹出分享按钮
 */
declare function ShareMenu(): void;
/**
 * 注册分享回调，只有qq应用可以使用，空间不行
 */
declare function SetOnShareHandler(callback): void;
/**
 * 直接弹出分享界面
 */
declare function ShareMessage(params, callback): void;
/**
 * 获得openid
 */
declare function GetOpenid(): string;
/**
 * 获得openkey
 */
declare function GetOpenkey(): string;
/**
 * 获得pf
 */
declare function GetPF(): string;
/**
 * 获得设备信息 平台，2-IOS，1-安卓
 */
declare function GetPlatform(): number;
/**
 * 弹出支付窗口
 */
declare function PopPayTips(score): void;
/**
 * 注册
 */
declare function ReportRegister(): void;
/**
 * 登入
 */
declare function ReportLogin(): void;
/**
 * 设置支付成功回调
 */
declare function SetPaySuccess(callback): void;
/**
 * 设置支付失败回调
 */
declare function SetPayError(callback): void;
/**
 * 设置支付关闭回调
 */
declare function SetPayClose(callback): void;