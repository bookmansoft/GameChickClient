function openUrl(){
     mqq.invoke("ui", "openUrl",{
            url     : "http://news.qq.com",
            target  : 1,
            style   : 1
        });
}

function ShareMenu() {
    mqq.ui.showShareMenu();
}

function SetOnShareHandler(callback){
    mqq.ui.setOnShareHandler(callback);
}

function ShareMessage(params, callback){
    params["share_url"] = eval(params["share_url"]);
    mqq.ui.shareMessage(params, callback);
}

function PopPayTips(score){
    window.popPayTips({defaultScore:score, appid:1105943531});
}

function GetOpenid(){
    return window.OPEN_DATA.openid;
}

function GetOpenkey(){
    return window.OPEN_DATA.openkey;
}

function GetPF(){
    return window.OPEN_DATA.pf;
}

function GetPlatform(){
    return window.OPEN_DATA.platform;
}

function ReportRegister(){
    window.reportRegister();
}

function ReportLogin(){
    window.reportLogin();
}

function SetPaySuccess(callback){
    window.__paySuccess = callback;
}

function SetPayError(callback){
    window.__payError = callback;
}

function SetPayClose(callback){
    window.__payClose = callback;
}